package dev.foxgirl.neoforge;

import net.neoforged.fml.common.Mod;

import dev.foxgirl.ExampleMod;

@Mod(ExampleMod.MOD_ID)
public final class ExampleModNeoForge {
    public ExampleModNeoForge() {
        // Run our common setup.
        ExampleMod.init();
    }
}
