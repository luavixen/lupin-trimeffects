package dev.foxgirl;

public final class ExampleMod {
    public static final String MOD_ID = "trimeffects";

    public static void init() {
        // Write common init code here.
    }
}
